# AI search project

## Instructions:

Restart the grid - press 'r'
Add and remove columns - press 'q' and 'w'
Add and remove rows - press '1' and '2'
Exit - press 'esc'

## Level editor

Left click - Change state of the current cell hovered with the mouse
Right click - Change the value to assign (the color of the mouse reflects the current state to assign)
